package pctexercicio5c;

public class Exercicio5c {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double[][] matriz = new double[3][3];

		matriz[0][0] = 1.9;
		matriz[0][1] = 2.5;
		matriz[0][2] = 10.0;

		matriz[1][0] = 1.0;
		matriz[1][1] = 7.8;
		matriz[1][2] = 2.5;

		matriz[2][0] = 3.5;
		matriz[2][1] = 2.2;
		matriz[2][2] = 4.7;

		for (int i = 0; i < 3; i++) {
			
			for (int j = 0; j < 3; j++) {
				System.out.print(" " + matriz[i] [j] +" ");
			}
			System.out.println();

		}
		
		}


	}
