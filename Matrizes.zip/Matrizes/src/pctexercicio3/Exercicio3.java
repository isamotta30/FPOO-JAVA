package pctexercicio3;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] vetorUm = new int[5];
		Scanner entrada = new Scanner(System.in);
		int aux = 0;
		for (int i = 0; i < 5; i++) {
			System.out.println("Digite o seu número inteiro:");
			vetorUm[i] = entrada.nextInt();
			aux = aux + vetorUm[i];
		}
		System.out.println("A soma é: " + aux);
		System.out.println("A média será:" + aux / 5);

		for (int i = 0; i < 5; i++) {
			
			if (vetorUm[i] > (aux/5)) {
				System.out.println(vetorUm[i] + " Maior que a média: ");
			} else {
				System.out.println(vetorUm[i] + " Menor que a média:");
			}
		}
		entrada.close();

	}
}
