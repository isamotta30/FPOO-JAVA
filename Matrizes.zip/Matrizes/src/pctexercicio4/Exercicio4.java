package pctexercicio4;

import java.util.Scanner;

public class Exercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int teste=0;
		int[] vetor=new int[10];
		try (Scanner entrada = new Scanner(System.in)) {
			
			for (int i = 0; i < 10; i++) {
				System.out.println("Digite os valores reais:");
				vetor[i]=entrada.nextInt();
}
		}
		
		for(int i=11;i>=10;i--);{
		
			teste=teste;
			System.out.println(teste);
}
		}
	}

		
	

