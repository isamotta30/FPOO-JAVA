package pctexercicio5;

public class Exercicio5 {

	public static void main(String[] args) {
		String[][] letras = new String[4][5];

		letras[0][0] = "a";
		letras[0][1] = "b";
		letras[0][2] = "c";
		letras[0][3] = "d";
		letras[0][4] = "e";

		letras[1][0] = "f";
		letras[1][1] = "g";
		letras[1][2] = "h";
		letras[1][3] = "i";
		letras[1][4] = "j";

		letras[2][0] = "l";
		letras[2][1] = "m";
		letras[2][2] = "n";
		letras[2][3] = "o";
		letras[2][4] = "p";

		letras[3][0] = "q";
		letras[3][1] = "r";
		letras[3][2] = "s";
		letras[3][3] = "t";
		letras[3][4] = "u";

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print(" " + letras[i][j] + " ");
			}
			System.out.println();

		}
		
		}
}

