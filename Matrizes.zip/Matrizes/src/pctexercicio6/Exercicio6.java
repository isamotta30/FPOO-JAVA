package pctexercicio6;

import java.util.Scanner;

public class Exercicio6 {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner entrada = new Scanner(System.in)) {
			int[][] matriz = new int[5][5];
			int soma = 0;

			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {
					System.out.println("Digite o valor: ");
					matriz[i][j] = entrada.nextInt();
				}
			}

			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {
					System.out.print(" | " + matriz[i][j] + " ");
				}
				System.out.print("|");
				System.out.println();
			}
			System.out.println("a soma da primeira coluna : "+ (matriz[0][0]+ matriz[1][0] + matriz[2][0] + matriz[3][0] + matriz[4][0]));
			System.out.println("a soma da segundacoluna : "+ (matriz[0][1]+ matriz[1][1] + matriz[2][1] + matriz[3][1] + matriz[4][1]));
			System.out.println("a soma da terceira coluna : "+ (matriz[0][2] + matriz[1][2]+ matriz[2][2] + matriz[3][2] + matriz[4][2]));
			System.out.println("a soma da quarta coluna : "+ (matriz[0][3] + matriz[1][3] + matriz[2][3] + matriz[3][3] + matriz[4][3]));
			System.out.println("a soma da quinta coluna : "+ (matriz[0][4] + matriz[1][4] + matriz[2][4] + matriz[3][4] +  matriz[4][4]));
			System.out.println("");
			System.out.println("");
			System.out.println("a soma da primeira linha: "+ ( matriz[0][0] +  matriz[0][1] +  matriz[0][2]+  matriz[0][3] +  matriz[0][4]));
			System.out.println("a soma da segunda linha: "+ ( matriz[1][0]+  matriz[1][1] +  matriz[1][2] +  matriz[1][3] +  matriz[1][4]));
			System.out.println("a soma da terceira linha: "+ ( matriz[2][0]+  matriz[2][1] +  matriz[2][2] +  matriz[2][3] +  matriz[2][4]));
			System.out.println("a soma da quarta linha: "+ ( matriz[3][0]+  matriz[3][1] +  matriz[3][2] +  matriz[3][3] +  matriz[3][4]));
			System.out.println("a soma da quinta linha : "+ ( matriz[4][0] +  matriz[4][1] +  matriz[4][2] +  matriz[4][3] +  matriz[4][4]));
		}

	}
}
