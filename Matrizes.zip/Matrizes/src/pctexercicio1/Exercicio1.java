package pctexercicio1;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		try (Scanner input = new Scanner(System.in)) {
			int[][] numero = new int[3][3];

			for (int i = 0; i < 3; i++) {

				for (int j = 0; j < 3; j++) {
					System.out.println("Digite um número:");
					numero[i][j] = input.nextInt();

				}

				System.out.println("|" + numero[0][0] + "");
				System.out.println("|" + numero[0][1] + "");
				System.out.println("|" + numero[0][2] + "");

				System.out.println("|" + numero[1][0] + "");
				System.out.println("|" + numero[1][1] + "");
				System.out.println("|" + numero[1][2] + "");

				System.out.println("|" + numero[2][0] + "");
				System.out.println("|" + numero[2][1] + "");
				System.out.println("|" + numero[2][2] + "");

			}
		}
	}
}

	
	
		
	



