package pctexercicio2;

public class Exercicio2 {

	public static void main(String[] args) {
		String[] [] clientes=new String[3] [4];

		clientes[0] [0]="João";
		clientes[0] [1]="Rua das Flores,123";
		clientes[0] [2]="391.438.111-67";
		clientes[0] [3]="15(99)490-05-21";
		
		clientes[1] [0]="Maria";
		clientes[1] [1]="Avenida dos anjos,456";
		clientes[1] [2]="271.292.668-48";
		clientes[1] [3]="15(99)952-74-21";
		
		clientes[2] [0]="Pedro";
		clientes[2] [1]="Praça da Liberdade,789";
		clientes[2] [2]="546.532.648-48";
		clientes[2] [3]="15(99)082-60-38";
		
		for (int i=0; i<3;i++) {
			System.out.println("Nome:" + clientes[i] [0]);
			System.out.println("Endereço:" + clientes[i] [1]);
			System.out.println("CPF:" + clientes[i] [2]);
			System.out.println("Telefone:" + clientes[i] [3]);
			
			System.out.println();
		}
	}


		}
	


