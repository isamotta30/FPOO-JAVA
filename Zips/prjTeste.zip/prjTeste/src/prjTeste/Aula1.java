package prjTeste;

import java.util.Scanner;

public class Aula1 {
     
	public static void main(String[] args) {
	String nome;
	//criando a variável sc para receber o que será digitado
	Scanner sc = new Scanner(System.in);
	System.out.println("Digite seu nome: ");
	nome=sc.nextLine();
	System.out.println(nome);
	
	
	     

		
		
		
		
	}
 
	
	
	
	
	
}
