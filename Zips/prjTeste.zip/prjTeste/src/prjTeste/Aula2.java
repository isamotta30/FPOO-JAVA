package prjTeste;

public class Aula2 {
	 int a=10,b=20, soma = a+b;
		
		
     System.out.println("A soma dos dois números é igual a: " + soma);

}
