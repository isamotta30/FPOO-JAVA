package pctExercicio3;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner leitura = new Scanner(System.in)) {
			int num1, num2,resposta;
		
			System.out.println("Digite o  quanto você ganha por hora: ");
			num1 = leitura.nextInt();
			System.out.println("Número de horas trabalhadas no mês: ");
			num2 = leitura.nextInt();
     System.out.println("Total do salário no mês é R$:"+(num1*num2));
     
     System.out.println("Deseja finalizar?:");
     System.out.println("Sim Não");
		resposta = leitura.nextInt();
			}
	}
		}

