package pctExercicio1;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner leitura = new Scanner(System.in);
		byte opcao = 1;
		int num1;

		while ((opcao != 0) && (opcao <= 10)) {
			System.out.println("Digite um número de 0 a 10:");

			opcao = leitura.nextByte();

			switch (opcao) {
			case 1:
				System.out.println("Um");
				num1 = leitura.nextInt();

			case 2:
				System.out.println("Dois");
				num1 = leitura.nextInt();

			case 3:
				System.out.println("Três");
				num1 = leitura.nextInt();

			case 4:
				System.out.println("Quatro");
				num1 = leitura.nextInt();

			case 5:
				System.out.println("Cinco");
				num1 = leitura.nextInt();

			case 6:
				System.out.println("Seis");
				num1 = leitura.nextInt();

			case 7:
				System.out.println("Sete");
				num1 = leitura.nextInt();

			case 8:
				System.out.println("Oito");
				num1 = leitura.nextInt();

			case 9:
				System.out.println("Nove");
				num1 = leitura.nextInt();

			case 10:
				System.out.println("Dez");
				num1 = leitura.nextInt();
			}

		}
		leitura.close();

	}
}
