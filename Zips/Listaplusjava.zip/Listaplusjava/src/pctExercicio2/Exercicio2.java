package pctExercicio2;

import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
				Scanner entrada = new Scanner(System.in)) {
			int km, resposta = 0;
			do {
				System.out.println("Quantos km/h você está?:");
				km = entrada.nextInt();

				if (km >= 50) {
					System.out.println((km - 50) * 5);
					System.out.println("Há multa " + ((km - 50) * 5));

				} else {
					System.out.println("Não há multa");

					System.out.println("Deseja continuar?:");
					System.out.println("1-Não");
					System.out.println("2-Sim");

					resposta = entrada.nextInt();

				}
			} while (resposta != 2);

		}
	}

}
