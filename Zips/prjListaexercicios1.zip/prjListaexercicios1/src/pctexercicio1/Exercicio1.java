package pctexercicio1;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
                int num1,num2,num3;
		
		
		Scanner entrada= new Scanner(System.in);
		  
	     System.out.println("Digite a primeira nota:");
	     num1=entrada.nextInt();
	     
	     System.out.println("Digite a segunda nota:");
	     num2=entrada.nextInt();
	     
	     
	     System.out.println("A soma das notas é:" +(num1+num2));
	     num3=((num1+num2)/2);
	     System.out.println("A média é:"+num3);
	
	     if(num3>=7) {
	     	System.out.println(" Passou");	     
		}else{
	         System.out.println(" reprovado");}  
	     
	     entrada.close();

	}

}
