package pctexercicio4;

import java.util.Scanner;

public class Exercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1, num2;
		
		Scanner entrada = new Scanner(System.in);
		System.out.println("Digite o seu salário: ");
		num1 = entrada.nextInt();
		System.out.println("Quanto tempo você tem de contribuição: ");
		num2 = entrada.nextInt();

		if(num2>=5){

		System.out.println(num1+((num1*20)/100));


		}else {

		System.out.println(num1+((num1*10)/100));
		
		entrada.close();

		}
}

}
