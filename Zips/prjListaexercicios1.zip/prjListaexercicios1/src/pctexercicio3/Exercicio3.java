package pctexercicio3;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
         int num1,num2,num3;
        
        Scanner entrada= new Scanner(System.in);
        
        System.out.println("Digite um número:");
        num1=entrada.nextInt();

        System.out.println("Digite um número:");
        num2=entrada.nextInt();
        
        System.out.println("Digite um número:");
        num3=entrada.nextInt();
        
        
         if((num1>num2) & (num2>num3)) {
       	  
	          System.out.println(" O número maior é o:" +num1);	  
         
	     }else if((num2>num1) & (num2>num3)) {
				   System.out.println(" O número maior é o:" +num2);	 
			    
		 }else if((num3>num1) & (num3>num2))
			 	    System.out.println(" O número maior é o:" +num3);	 
			     
         
         entrada.close();
			     }
}
	