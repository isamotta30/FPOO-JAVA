package pctexercicio7;

import java.util.Scanner;

public class Exercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1,n2;
		
	Scanner entrada= new Scanner(System.in);
    	   
	   System.out.println("O valor das vendas feita no mês de abril é:");
	   n1= entrada.nextInt(); 
	   n2=1200;
	   
		
	   if (n1>=2000) {
		System.out.println("10% do valor vendido foi atribuido ao seu sálario bruto,salário final:"+(n2+(n1*10/100)));
		
	     }else{
	  
			System.out.println("Valor da venda não correspondido,salário:" +n2);
	     
	    
		entrada.close();
	       		
	       }
	       
	    }
}