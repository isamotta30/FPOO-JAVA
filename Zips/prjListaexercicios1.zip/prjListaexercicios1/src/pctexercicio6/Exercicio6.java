package pctexercicio6;

import java.util.Scanner;

public class Exercicio6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1;
	
		Scanner entrada= new Scanner(System.in);
			
		  System.out.println("Digite o número :");
		  num1=entrada.nextInt();
		  
	         if(num1%2==0){
		    	 System.out.println("Número par");
		     }else{
		    	 System.out.println("Número impar");
		    	 entrada.close();
		    	 
		    	 
			}   
	     }
	}

