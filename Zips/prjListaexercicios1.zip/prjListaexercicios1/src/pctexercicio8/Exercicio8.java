
package pctexercicio8;

import java.util.Scanner;

public class Exercicio8 {

	public static void main(String[] args) {
		char opcao;
		double num1;
		
	 Scanner entrada= new Scanner(System.in);
	 
	 System.out.println("Informe o seu sexo:");
	 
	 System.out.println("A-Masculino");
	 
	 System.out.println("B-Feminino");
     opcao=entrada.nextLine().charAt(0);
     
     System.out.println("Digite a sua altura:");
     num1=entrada.nextDouble();
     switch(opcao) {
     
     case 'A':
    	 
    	 System.out.println("O peso ideal de acordo com seu sexo (Masculino) é aproximadamente:" +((72.7*num1)-58));
    	 
    	 break;
    	 
     case 'B':
    	 
    	 System.out.println("O peso ideal de acordo com seu sexo (Feminino) é aproximadamente:" +((62.1*num1)-44.7));
     }
    	 entrada.close();
		}
	     }
	


