package pctexercicio9;

import java.util.Scanner;

public class Exercicio9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double hs, ms;
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Quantas horas no estacionamento:");
        hs = entrada.nextDouble();
        System.out.println("Quantos minutos no estacionamento:");
        ms = entrada.nextDouble();
        if((hs==0) && (ms>=60)) {
            System.out.println("O valor a ser pago será de R$4,00");}
        else if ((hs==1) && (ms==0)) {
            System.out.println("O valor a ser pago será de R$4,00");}
        else if((hs==1) && (ms==1) && (ms<61)) {
            System.out.println("O valor a ser pago será de R$6,00");}
        else if ((hs==2) && (ms==0)) {
            System.out.println("O valor a ser pago será de R$6,00");}
        else if ((hs==2) && (ms==0) && (ms<61)) {
            System.out.println("O valor a ser pago será de R$"+ 6.00+1);}
        else if ((hs==3) && (ms==0)) {
            System.out.println("O valor a ser pago será de R$"+ 6.00+1);}
        else if ((hs==4) && (ms>=0) && (ms<61)) {
            System.out.println("O valor a ser pago será de R$" +7.00+1);}
        else if ((hs==4) && (ms==0)) {
            System.out.println("O valor a ser pago será de R$" +(hs-2)+6.00);}
        else if ((hs==4) && (ms>=1)) {
            System.out.println("O valor a ser pago será de R$" +(hs-2)+7.00);}
        entrada.close();
	               }
		
	}

