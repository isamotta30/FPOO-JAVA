package pctexercicio10;

import java.util.Scanner;

public class Exercicio10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double n2, n3;

		int num, n1;

		Scanner entrada = new Scanner(System.in);

		System.out.println("Informe o combustível :");

		System.out.println("A- Gasolina");

		System.out.println("B- Álcool");

		num = entrada.nextLine().charAt(0);

		System.out.println("Informe a Capacidade do Tanque :");

		n1 = entrada.nextInt();

		n2 = 1.80;

		n3 = 1.00;

		switch(num) {

		case 'A':

		System.out.println("O preço a ser pago ao por gasolina será de R$:" +n1*n2);

		break;

		case 'B':

		System.out.println("O preço a ser pago ao por Álcool será de R$: " +n1*n3);

		break;

		}

		entrada.close();

		}

	}


