package pctexercicio5;

import java.util.Scanner;

public class Exercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num3,num4,num5;
		
		Scanner entrada= new Scanner(System.in);
		
		System.out.println("Valor do emprestimo: ");

		num3= entrada.nextInt();

		System.out.println("Número de parcelas ");

		num4= entrada.nextInt();

		System.out.println("Escreva seu salario ");
		num5= entrada.nextInt();

		if((num3/num4) <= (num5*30/100)){

		System.out.println("Emprestimo negado ");


		}else {

		System.out.println("Emprestimo aceito ");
		
		entrada.close();

		}

		}

		}