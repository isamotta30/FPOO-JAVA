package prjAula2;

import java.util.Scanner;

public class Exercicio1 {

	private static int num4;
	private static int num5;

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner entrada = new Scanner(System.in)) {
			/*exercicio5*/
			int num1 = 0,num2 = 0,num3;

			System.out.println("valor do emprestimo ");

			num3 = entrada.nextInt();

			System.out.println("numero de parcelas ");

			num4 = entrada.nextInt();

			System.out.println("escreva seu salario ");

			num5 = entrada.nextInt();


			if((num1/num2) <= (num3*30/100)){

			System.out.println("emprestimo negado ");


			}else {

			System.out.println("emprestimo aceito ");

			}
		}

		}

		}

 

