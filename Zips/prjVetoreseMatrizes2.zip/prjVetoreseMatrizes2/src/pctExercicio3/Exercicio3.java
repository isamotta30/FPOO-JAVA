package pctExercicio3;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] vetor = new int[5];
		int[] vetorDois = new int[5];
		int[] ve = new int[5];
		
		try (Scanner entrada = new Scanner(System.in)) {
			for (int i = 0; i < 10; i++) {
				System.out.println("Digite o valor do primeiro vetor:");
                vetor[i] = entrada.nextInt();
			}
			}
		for (int i = 0; i < 5; i++) {
			System.out.println("Digite o valor do segundo vetor:");
			Scanner entrada = null;
			vetorDois[i] = entrada.nextInt();
		}
		
		for (int i = 0; i < 10; i++) {
			ve[i]=vetor[i]+vetorDois[i];
		}
		for (int i = 0; i < 5; i++) {
			System.out.println("Soma do valor do primeiro e segundo vetor são:");
		}
		}
	}


	

	
	



