package pctExercicio2;

import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] vetor = new int[10];

		int[] vetorDois = new int[10];

		int aux = 0;

		try (Scanner entrada = new Scanner(System.in)) {
			for (int i = 0; i < 10; i++) {

				System.out.println("Digite a sua nota:");

				vetor[i] = entrada.nextInt();

			}
		}
		for (int i = 0; i < 10; i++) {
			vetorDois[i] = vetor[i] * 2;

		System.out.println("O valor final é:" + vetorDois[i]);
		}

	}
}
