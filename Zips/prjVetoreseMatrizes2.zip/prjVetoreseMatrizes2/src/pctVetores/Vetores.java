package pctVetores;

import java.util.Scanner;

public class Vetores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// defino tipo, nome , quantidade de itens

		int[] vetorUm = new int[10];

		int aux = 0;

		try (Scanner entrada = new Scanner(System.in)) {
			for (int i = 0; i < 10; i++) {

				System.out.println("Digite a sua nota:");

				vetorUm[i] = entrada.nextInt();

			}
		}

		// percorrendo com for e preencher com valores

		for (int i = 0; i < 10; i++) {
			aux = aux + vetorUm[i];
		}
		System.out.println("A média será:" + aux / 10);

	}
}
