package pctexercicio4;

import java.util.Scanner;

public class Exercicio4 {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
	Scanner leitura = new Scanner (System.in)) {
			
			Scanner sc=new Scanner(System.in);
			int n = sc.nextInt();
			
			 while (n>0) {
				 System.out.println(n+"patinhos foram passear");
				 System.out.println("Além das montanha");
				 System.out.println("Para brincar");
				 System.out.println("A mamãe gritou: Quá, quá, quá, quá ");
				 n--;
				 if(n==0);
				 System.out.println("Mas nenhum patinho voltou de lá");
			 }else{
				 System.out.println("Mas só" + n + "patinhos voltaram de lá");
			 }
		}
		
		System.out.println("Todos os patinhos voltaram");
			
	}
}


			
			
			
			
			
			
	}
	}

}
