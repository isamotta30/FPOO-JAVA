package pctexercicio1;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1,n2 = 0;
		 try (Scanner leitura = new Scanner (System.in)) {
			byte opcao=1;
			while((opcao !=0) && (opcao<=4));
			System.out.println("Escolha uma operação:");
			System.out.println("(0) Sair");
			System.out.println("(1) Somar");
			System.out.println("(2) Subtrair");
			System.out.println("(3) Multiplicar");
			System.out.println("(4) Dividir");
			System.out.println("(?) Opção: ");
			opcao=leitura.nextByte();
			
	 int re;
	if(opcao==1) {
		System.out.println("Digite o primeiro número:");
		 n1=(int) leitura.nextDouble();
		 
		System.out.println("Digite o segundo número:");
		 n1=(int) leitura.nextDouble();
		re=n1+n2;
		System.out.println("O resultado da soma é:" + re);
		
	 } else if (opcao==2) {
				System.out.println("Digite o primeiro número:");
				 n1=(int) leitura.nextDouble();
				 
				System.out.println("Digite o segundo número:");
				 n1=(int) leitura.nextDouble();
			re=n1-n2;
				System.out.println("O resultado da subtração é:" + re);
				
			 } else if (opcao==3) {
						System.out.println("Digite o primeiro número:");
						 n1=(int) leitura.nextDouble();
						 
						System.out.println("Digite o segundo número:");
						 n1=(int) leitura.nextDouble();
						 re=n1*n2;
						System.out.println("O resultado da multiplicação é:" + re);
						
					 } else if (opcao==4) {
								System.out.println("Digite o primeiro número:");
								 n1=(int) leitura.nextDouble();
								 
								System.out.println("Digite o segundo número:");
								n1=(int) leitura.nextDouble();
								if (n2==0) {
										
								System.out.println("Não é possível dividir por zero");
							 } else {
								
								re=n1/n2;
								 System.out.println("O resultado da divisão é:" + re);
					            }
								
					 }else if (opcao!=0) {
						 System.out.println("Opção Inválida.");
	 }

	 }

		 
	}

}
