package pctexercicio3;

import java.util.Random;
import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
	// TODO Auto-generated method stub
		Random rnd=new Random();
		int num2=rnd.nextInt(10);//Gera um número aleatório (0-10)
		 int num;
		try (Scanner sc = new Scanner(System.in)) {
			do {
				   System.out.print("Digite um número entre 0 e 9:");
				   num=sc.nextInt();
				   
				   if (num< num2) {
					   System.out.println("MAIOR");
					   
				   } else if (num>num2) {
					   System.out.println("MENOR");
				   }
			  }while(num!=num2);
		}
		
		  System.out.println("Acertou o número!");
			     
				   }	 
		}
		  