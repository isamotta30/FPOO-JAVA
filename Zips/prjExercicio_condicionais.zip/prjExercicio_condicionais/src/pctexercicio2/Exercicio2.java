package pctexercicio2;

import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num,in,fim,resultado;
      try (Scanner leitura = new Scanner (System.in)) {
		System.out.print("Montar a tabuada de:");
		   num=leitura.nextInt(0);
		   
		    System.out.print("Começo em:");
		    in=leitura.nextInt();
		    
		    System.out.print("Terminar em:");
		    fim=leitura.nextInt();
	}
    		   if(fim<in) {
    		    	 System.out.println("O valor final não pode ser menor que o valor inicial");
    		     } else {
    		    	 System.out.println("A tabuada vai ser de " +num+ "começando em" +in+ " e terminando em" +fim+ ";");
    		    	 for (int i=in; i<= fim; i ++) {
    		    		    resultado= num*i;
    		    		   System.out.println(num+"x" + i+ "= +re");
    		    	 
    		    	 
    		     }
	}
	}
	}


