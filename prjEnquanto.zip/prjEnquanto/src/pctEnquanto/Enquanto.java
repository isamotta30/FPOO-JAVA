package pctEnquanto;

import java.util.Scanner;

public class Enquanto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int num;
        try (Scanner scanner = new Scanner(System.in)) {
			do {
			    System.out.print("Digite um número inteiro maior que 0 e menor que 100: ");
			    num = scanner.nextInt();
			} while (num<=1);
		}
       
        for (int i=num+1;i<=100;i++) {
            if (i%2!=0) {
                System.out.print(i);
                if (i!=99) {
                    System.out.print(",");
                    
                }
            }
            
            System.out.println("");
            System.out.println("Digite um número de 0 a 100");
            num=entrada;
        }
    
}
}
